export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyDVGGS_a-8lOQjq-xhh-YX_bMeqqOBiaHg',
    authDomain: 'taskflow-app-000.firebaseapp.com',
    databaseURL: 'https://taskflow-app-000-default-rtdb.firebaseio.com', 
    projectId: 'taskflow-app-000',
    storageBucket: 'taskflow-app-000.appspot.com',
    messagingSenderId: '263250090666',
    appId: '1:263250090666:web:c74b272d1ca273372f8ed3',
    measurementId: '' 
  }
};
