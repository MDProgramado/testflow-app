export interface Sumary {
    label: string;
    count: number;
    color: string;
    icon: string,
    route: string;
}