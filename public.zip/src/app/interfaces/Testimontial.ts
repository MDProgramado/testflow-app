export interface Testimonial {
  stars: number;
  text: string;
  author: string;
  role: string;
  initials: string;
}