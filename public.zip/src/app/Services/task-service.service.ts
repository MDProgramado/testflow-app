import { Injectable, inject } from '@angular/core';
import { Observable, from, of, switchMap, tap, map } from 'rxjs';
import { Task } from '../interfaces/Task';
import { NotificationService } from './notification.service';
import { Auth, user } from '@angular/fire/auth';


import { 
  Firestore, 
  collection, 
  collectionData, 
  doc, 
  docData,
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where 
} from '@angular/fire/firestore';
import { AutentificarLoginService } from './autentificar-login.service';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService { // Renomeei para TaskService para simplificar

  private firestore: Firestore = inject(Firestore);
  private notificationService: NotificationService = inject(NotificationService);
  private authService: AutentificarLoginService = inject(AutentificarLoginService); // 2. INJETAMOS O AUTHSERVICE

  /**
   * Busca tarefas com base no papel (role) do usuário logado.
   * - Admin: Vê todas as tarefas.
   * - Editor: Vê apenas as tarefas do seu setor.
   */
  getAll(): Observable<Task[]> {
    // Usamos o authService para pegar o perfil completo do usuário (com a 'role')
    return this.authService.getCurrentUser().pipe(
      switchMap(user => {
        if (!user) {
          return of([]); // Retorna array vazio se não estiver logado
        }
        
        const tasksCollection = collection(this.firestore, 'tasks');
        let q; // Nossa variável de query

        // LÓGICA DE PERMISSÕES
        if (user.role === 'admin') {
          // ADMIN: Busca todos os documentos da coleção 'tasks'
          console.log('Usuário é admin. Buscando todas as tarefas.');
          q = query(tasksCollection); 
        } else {
          // EDITOR: Busca apenas onde o campo 'sector' é igual ao setor do usuário
          console.log(`Usuário é editor. Buscando tarefas do setor: ${user.sector}`);
          q = query(tasksCollection, where('sector', '==', user.sector));
        }
        
        // Retornamos os dados e ordenamos no cliente para funcionar no plano Spark
        return (collectionData(q, { idField: 'id' }) as Observable<Task[]>).pipe(
          map(tasks => tasks.sort((a, b) => {
            if (!a.dueDate) return 1;
            if (!b.dueDate) return -1;
            return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
          }))
        );
      })
    );
  }
 
  /**
   * Cria uma nova tarefa, associando-a ao setor do usuário.
   */
  create(task: Partial<Task>): Observable<string | null> {
    // Usamos o authService para garantir que temos o perfil completo para associar o setor
    return this.authService.getCurrentUser().pipe(
      switchMap(user => {
        if (!user) {
          throw new Error('Usuário não autenticado para criar tarefa.');
        }
        const tasksCollection = collection(this.firestore, 'tasks');
        // 3. AJUSTE: Adicionamos o 'userId' E o 'sector' do usuário na nova tarefa
        const taskToCreate = { 
          ...task, 
          userId: user.uid,
          sector: user.sector // Essencial para a filtragem do editor
        }; 
        
        return from(addDoc(tasksCollection, taskToCreate)); 
      }),
      map(docRef => docRef.id), 
      tap(newId => {
        this.notificationService.showNotification(
          `Tarefa '${task.title}' foi criada com sucesso!`, 'info',
          { link: `/tasks/${newId}` }
        );
      })
    );
  }

  // Os métodos abaixo não precisam de alteração, pois operam em um
  // ID específico, e a segurança deles é garantida pelas Regras do Firestore.
  
  getById(id: string): Observable<Task | null> {
    const taskDocRef = doc(this.firestore, `tasks/${id}`);
    return docData(taskDocRef, { idField: 'id' }) as Observable<Task | null>;
  }

  update(id: string, taskData: Partial<Task>): Observable<void> {
    const taskDocRef = doc(this.firestore, `tasks/${id}`);
    return from(updateDoc(taskDocRef, taskData)).pipe(
      tap(() => {
        this.notificationService.showNotification(`Tarefa atualizada com sucesso!`, 'info');
      })
    );
  }

  delete(id: string): Observable<void> {
    const taskDocRef = doc(this.firestore, `tasks/${id}`);
    return from(deleteDoc(taskDocRef)).pipe(
      tap(() => {
        this.notificationService.showNotification(`Tarefa removida com sucesso.`, 'warning');
      })
    );
  }

  checkTaskDeadLines(tasks: Task[]): void {
    const currentDate = new Date();
    tasks.forEach(task => {
      if (task.status !== "Concluída" && task.id) {
        const deadLineDate = new Date(task.dueDate);
        if (isNaN(deadLineDate.getTime())) return;
        
        const timeDiff = deadLineDate.getTime() - currentDate.getTime();
        const dayDiff = timeDiff / (1000 * 3600 * 24);

        const notificationKey = `notified_${task.id}`;
        if (sessionStorage.getItem(notificationKey)) return;

        if (dayDiff < 0) {
          this.notificationService.showNotification(
            `A tarefa '${task.title}' ultrapassou o prazo!`, 'error',
            { silent: false, link: `/tasks/${task.id}` }
          );
          sessionStorage.setItem(notificationKey, 'true');
        } else if (dayDiff >= 0 && dayDiff <= 2) {
            this.notificationService.showNotification(
            `A tarefa '${task.title}' está perto do prazo!`, 'warning',
            { silent: false, link: `/tasks/${task.id}` }
          );
            sessionStorage.setItem(notificationKey, 'true');
        }
      }
    });
  }
}