import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, from, of, switchMap, catchError, tap, map, BehaviorSubject, throwError } from 'rxjs';


import { Auth, signInWithEmailAndPassword, signOut, User, createUserWithEmailAndPassword, authState} from '@angular/fire/auth';


import { Firestore, doc, docData, setDoc } from '@angular/fire/firestore';


import { UserProfile } from '../interfaces/UserProfile';
@Injectable({
  providedIn: 'root'
})
export class AutentificarLoginService { 

  private auth: Auth = inject(Auth);
  private firestore: Firestore = inject(Firestore);
  private router: Router = inject(Router);

  private currentUser$ = new BehaviorSubject<UserProfile | null | undefined>(undefined);
 

  constructor() {
    
    authState(this.auth).pipe(
      switchMap(user => {
        if (user) {
         
          return this.fetchUserProfile(user);
        } else {
        
          return of(null);
        }
      })
    ).subscribe(profile => {

      this.currentUser$.next(profile);
    });
  }

  getCurrentUser(): Observable<UserProfile | null> {
    return this.currentUser$.pipe(
      map(user => user || null)
    );
  }

  login(email: string, senha: string): Observable<UserProfile> {
    return from(signInWithEmailAndPassword(this.auth, email, senha)).pipe(
      switchMap(userCredential => this.fetchUserProfile(userCredential.user)),
      tap(profile => {
       
        this.currentUser$.next(profile);
        this.router.navigate(['/dashboard']);
      }),
      catchError(error => {
        console.error("Erro no login:", error);
        return throwError(() => new Error('Email ou senha inválidos.'));
      })
    );
  }

  
  register(email: string, senha: string, displayName: string, sector?: string): Observable<void> {
    return from(createUserWithEmailAndPassword(this.auth, email, senha)).pipe(
      switchMap(userCredential => {
        const user = userCredential.user;
        const userProfile: Partial<UserProfile> = { 
          uid: user.uid,
          email: user.email!,
          displayName: displayName,
          role: 'editor', 
          sector: sector
        };
       
        const userDocRef = doc(this.firestore, `users/${user.uid}`);
        return from(setDoc(userDocRef, userProfile));
      })
    );
  }

  logout(): Observable<void> {
    return from(signOut(this.auth)).pipe(
      tap(() => {
       
        this.currentUser$.next(null);
        this.router.navigate(['/login']);
      })
    );
  }
 
  private fetchUserProfile(user: User): Observable<UserProfile> {
    const userDocRef = doc(this.firestore, `users/${user.uid}`);
    return docData(userDocRef) as Observable<UserProfile>;
  }
}