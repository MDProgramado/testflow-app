import { inject, Injectable } from '@angular/core';
import { Database, ref, listVal, update, set } from '@angular/fire/database';
import { Observable, from } from 'rxjs';
import { UserProfile } from '../interfaces/UserProfile';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private db: Database = inject(Database);

  getAllUsers(): Observable<UserProfile[]> {
    const usersRef = ref(this.db, 'users');
    return listVal<UserProfile>(usersRef, { keyField: 'uid' });
  }
 
  updateUserProfile(uid: string, data: Partial<UserProfile>): Observable<void> {
    const userRef = ref(this.db, `users/${uid}`);
    return from(update(userRef, data));
  }

  createUserProfile(uid: string, email: string, role: 'admin' | 'editor', sector?: string): Observable<void> {
    const userRef = ref(this.db, `users/${uid}`);
    
    const userProfileData = {
      email,
      role,
      
      sector: role === 'admin' ? null : (sector || null)
    };
    
    return from(set(userRef, userProfileData));
  }
}