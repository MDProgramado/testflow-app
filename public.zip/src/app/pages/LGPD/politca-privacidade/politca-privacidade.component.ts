import { Component } from '@angular/core';

@Component({
  selector: 'app-politca-privacidade',
  imports: [],
  templateUrl: './politca-privacidade.component.html',
  styleUrl: './politca-privacidade.component.css'
})
export class PolitcaPrivacidadeComponent {

}
