import { Component } from '@angular/core';

@Component({
  selector: 'app-termo-de-uso',
  imports: [],
  templateUrl: './termo-de-uso.component.html',
  styleUrl: './termo-de-uso.component.css'
})
export class TermoDeUsoComponent {

}
