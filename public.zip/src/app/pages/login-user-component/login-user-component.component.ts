import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';

 
import { UserProfile } from '../../interfaces/UserProfile';
import { AutentificarLoginService } from '../../Services/autentificar-login.service';

@Component({
  standalone: true,
  selector: 'app-login-user-component',
  imports: [ CommonModule, ReactiveFormsModule, RouterModule ],
  templateUrl: './login-user-component.component.html',
  styleUrls: ['./login-user-component.component.css']
})
export class LoginUserComponentComponent implements OnInit {
  
  formulario!: FormGroup;
  isLoading = false; 

  private fb: FormBuilder = inject(FormBuilder);
  
  private authService: AutentificarLoginService = inject(AutentificarLoginService); 
  private router: Router = inject(Router);
  private toastr: ToastrService = inject(ToastrService);
  
  ngOnInit(): void {
   
    this.formulario = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      senha: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.formulario.invalid) {
      this.toastr.warning('Preencha todos os campos corretamente.');
      return;
    }

    this.isLoading = true; 
    const { email, senha } = this.formulario.value;

 
    this.authService.login(email, senha).subscribe({ 
      next: (profile: UserProfile) => {
     
        this.toastr.success(`Bem-vindo, ${profile.displayName || profile.email}!`);

        if (profile.role === 'admin') {
          this.router.navigateByUrl('/dashboard');
        } else if (profile.role === 'editor' && profile.sector) {
          this.router.navigate(['/tasks'], { queryParams: { sector: profile.sector } });
        } else {
          this.router.navigateByUrl('/home'); 
        }
      },
      
      error: (err: Error) => {
        this.toastr.error(err.message, 'Falha no Login');
      },
    
      complete: () => {
        this.isLoading = false;
      }
    });
  }
}